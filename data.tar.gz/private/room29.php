<? include ('../inc.php');?>

<? $ROOM = 'room'; ?>
<? $NR = '29';?>
<? $secretroom = $peerkey29; ?>
<html>
<head>
  <title><?=$sitename;?> Video chat - <?=$ROOM;?> <?=$NR;?></title>
  <link rel="stylesheet" href="../css/camstyle.css">
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
  <script type="text/javascript" src="http://cdn.peerjs.com/0.3/peer.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script type="text/javascript" src="../js/webrtc-connection.js"></script>
  <script src="jquery.min.js"></script>
  <script src="jquery.zclip.min.js"></script>
<? include ('../settings/header.php');?>
<link rel="icon" type="image/png" href="../favicon.png">

  <script>

    // Compatibility shim
    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;

    // PeerJS object
    var peer = new Peer({ key: '<?=$secretroom;?>', debug: 3, config: {'iceServers': [
      { url: 'stun:stun.l.google.com:19302' } // Pass in optional STUN and TURN server for maximum network compatibility
    ]}});

    peer.on('open', function(){
      $('#my-id').text(peer.id);
    });

    // Receiving a call
    peer.on('call', function(call){
      // Answer the call automatically (instead of prompting user) for demo purposes
      call.answer(window.localStream);
      step3(call);
    });
    peer.on('error', function(err){
      alert(err.message);
      // Return to step 2 if error occurs
      step2();
    });

    // Click handlers setup
    $(function(){
      $('#make-call').click(function(){
        // Initiate a call!
        var call = peer.call($('#callto-id').val(), window.localStream);

        step3(call);
      });

      $('#end-call').click(function(){
        window.existingCall.close();
        step2();
      });

      // Retry if getUserMedia fails
      $('#step1-retry').click(function(){
        $('#step1-error').hide();
        step1();
      });

      // Get things started
      step1();
    });

    function step1 () {
      // Get audio/video stream
      navigator.getUserMedia({audio: true, video: true}, function(stream){
        // Set your video displays
        $('#my-video').prop('src', URL.createObjectURL(stream));

        window.localStream = stream;
        step2();
      }, function(){ $('#step1-error').show(); });
    }

    function step2 () {
      $('#step1, #step3').hide();
      $('#step2, #step4').show();
    }
	

    function step3 (call) {
      // Hang up on an existing call if present
      if (window.existingCall) {
        window.existingCall.close();
      }

      // Wait for stream on the call, then set peer video display
      call.on('stream', function(stream){
        $('#their-video').prop('src', URL.createObjectURL(stream));
      });

      // UI stuff
      window.existingCall = call;
      $('#their-id').text(call.peer);
      call.on('close', step2);
      $('#step1, #step2, #step4').hide();
      $('#step3').show();
    }

  </script>
<style type="text/css">
/*	body,td,th {
	color: <?=$roomtextcolor;?>;
}*/
body {
	background-image: url(<?=$siteurl;?>/<?=$bgimgrooms;?>);
	background-repeat: repeat;
}
    </style>
<script type="text/javascript">
<!--
 
$(document).ready(function () {
 
window.setTimeout(function() {
    $(".alert-success").fadeTo(1500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 6000);
 
});
//-->
</script>
</head>

<body>
<? include ('../settings/navbar.php');?>
<div class="container"><!---container--->

<?
// Timeout - After this time the users will
// be deleted (in minutes)
$timer = 1;
 
// Name of the file where all the data, about
// the user's activity will be saved
$filename = "../count/".$NR.".txt";
 
if (!isset($datei)) {
    $datei = $filename;
}
 
$time = @time();
$ip = $_SERVER['REMOTE_ADDR'];
$string = "$ip|$time\n";
$a = fopen("$filename", "a+");
fputs($a, $string);
fclose($a);
 
$timeout = time()-(10*$timer);
 
$all = "";
$i = 0;
$datei = file($filename);
for ($num = 0; $num < count($datei); $num++) {
    $pieces = explode("|",$datei[$num]);
 
    if ($pieces[1] > $timeout) {
        $all .= $pieces[0];
        $all .= ",";
    }
 
    $i++;
}
 
$all = substr($all,0,strlen($all)-1);
$arraypieces = explode(",",$all);
$useronline = count(array_flip(array_flip($arraypieces)));

// calculate
/* Correct Method: */
$a = $useronline;
$b = 100;
if($a > $b):
    echo "<div class='alert alert-warning' role='alert'><button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button>Not Looking good to setup a new connection here! Too Crowded Room".$NR." is Full: ".$a." of max ".$b." connections - Only invited users can enter the Key<br /><button type='button' class='btn btn-warning' data-dismiss='alert'>Close me and enter your Key</button></div>";
elseif($a == $b): // Note the combination of the words.
    echo "<div class='alert alert-warning' role='alert'><button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button>Not Looking good to setup a new connection here! Too Crowded Room".$NR." is Full: ".$a." of max ".$b." connections - Only invited users can enter the Key<br /><button type='button' class='btn btn-warning' data-dismiss='alert'>Close me and enter your Key</button></div>";
else:
    echo "<div id='alert' class='alert alert-success' role='alert'><button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span><span class='sr-only'>Close</span></button><i class='fa fa-2x fa-check-square-o'></i> <strong>Looking Good to setup a new connection</strong> Only ".$a." of max ".$b." visitors try to setup a connection in Room".$NR."<br /></div>";
endif;
 
// display how many people where active within $timeout
// echo $useronline;
 
// Delete
$dell = "";
for ($numm = 0; $numm < count($datei); $numm++) {
    $tiles = explode("|",$datei[$numm]);
    if ($tiles[1] > $timeout) {
        $dell .= "$tiles[0]|$tiles[1]";
    }
}
 
if (!$datei) $datei = dirname(__FILE__)."$filename";
 
$time = @time();
$ip = $_SERVER['REMOTE_ADDR'];
$string = "$dell";
$a = fopen("$filename", "w+");
fputs($a, $string);
fclose($a);
?>

<div class="row"><!---row--->
 
<div class="col-md-8"><!---col md 8--->
      <!-- Video area -->
      <!--<div class="pure-u-2-3" id="video-container">-->
        <video class="<?=$friendcam;?> img-thumbnail" id="their-video" autoplay></video>
        <video class="<?=$mycam;?> img-thumbnail" id="my-video" muted="true" autoplay></video>
      <!--</div>-->
</div><!---col md 8--->



<div class="col-md-4"><!---col md 4--->
      
        <h4>Video Chat - <?=$ROOM;?> <?=$NR;?></h4>

        <!-- Get local audio/video stream -->
        <div id="step1">
		<div class="panel panel-default">
		     <div class="panel-heading"><h4 class="panel-title">Step 1 access setup</h4></div>
             <div class="panel-body">
			 <p>Setup your webcam and microphone for calls.
             <h4>Please click <strong>allow</strong> on the top of the screen Above the menu bar!</h4>
			 </p>
			 
                  <div class="alert alert-danger" id="step1-error">
            <p><strong>Failed to access the webcam and microphone.</strong><br>Please Make sure to your cam is connected and click allow when asked for permission by the browser.</p>
            <a href="#" class="btn btn-danger btn-lg" id="step1-retry">Try again <i class="fa fa-spin fa-refresh"></i></a></br></br>
			<strong>WARNING! if you click Disallow you must reset your browser settings!</strong><br/>
			If you Don't want to setup a call<br>
			Just Close this Page tab. or your browser!
			<br/>
			 This will save you Lots of trouble the next time, If You do want to setup a Call.
			</br>
                  </div>
			</div>
		</div>
		</div>
        <!-- Get local audio/video stream -->
	

        <!-- Make calls to others -->
        <div id="step2"><!--step 2 -->
		<div class="panel panel-default">
		      <div class="panel-heading"><h4 class="panel-title">Step 2 - Setup the video call</h4></div>
              <div class="panel-body">
			  <h4>If you where invited enter the Given Key!</h4>
			   <small>Do Not enter the generated key from below yourself!</small><br/>
		       
                    <div class="pure-form">
                    <input type="text" placeholder="Given key.." id="callto-id">
                    <a href="#" class="btn btn-primary btn-sm" id="make-call"><i class="fa fa-lg fa-microphone"></i> Start Call</a>
                     </div>
		       <h4>Do Not close this page!</h4>
			   This will close the connection and key!<br>
		       This key is valid as long you keep this page open.<br/>
		       <strong>Tip!</strong>
			   <br>Use the menu tabs to share your key and room URL<br/>
			   To your friends on social networks or by email.<br/>
			   </div>
		  </div>
		  </div>
		  <!-- Make calls to others -->
		  
 <!---copy box---inherit--->		  
<div id="step4" class="panel panel-default">
<div class="panel-heading"><h4 class="panel-title">Invite someone</h4></div>
<div class="panel-body">
Share your Key and Room URL with others so they can call you.<br/>
And Wait till the other enters the Key here above.<br/>
<br/>
Copy and share the text below!<hr>		  
<script type="text/javascript">
$(function () {
$("#copy-to-clipboard").zclip({
path: 'ZeroClipboard.swf',
copy: function () { return $('.myresults-display').text(); },
beforeCopy: function () { $(".myresults-display").css("background-color", "lightgreen"); },
afterCopy: function () { $(".myresults-display").css("background-color", "lightgreen"); }
});
});
</script>
<div id="MainContentPlaceHolder_ResultsDisplay" class="myresults-display">
Hi, i want to chat with You, Just Go to:<br/>
<BIG><strong><?=$siteurl;?>/private/<?=$ROOM;?><?=$NR;?>.php</strong></BIG><br/>
Enter this Key to video chat with me.<br/>
<BIG id="my-id">...</BIG><br/>
Please Hurry Up i'm already waiting.
</div>
<hr>
<button class="btn btn-sm btn-primary" id="copy-to-clipboard" type="button">Copy to Clipboard</button> <button class="btn btn-sm btn-default" data-toggle="modal" data-target="#myModal">Help?</button>
</div>
</div>
<!---copy box------>
		 
		 
        <!-- Call in progress -->
        <div id="step3">
		<div class="panel panel-default">
		
		      <div class="panel-heading"><h3 class="panel-title">Step 3 connected</h3></div>
              <div class="panel-body">
              <p>Currently in call with <span id="their-id">...</span></p>
              <p><a href="#" class="btn btn-danger btn-lg" id="end-call">End Call <i class="fa fa-lg fa-sign-out"></i></a></p>
		      <br/>
			  <? include ('../settings/share.php');?><br/>
		      <? include ('../add1.php');?>
			  
              </div>
		</div>
		</div>
		<!-- Call in progress -->  
		 
		
     
</div><!-- ool md4 -->




	
	
  <div class="col-md-12">
  <? include ('../add2.php');?> 
  <hr />
 <? include ('../settings/footer.php');?> 
 </div>
 
 
 </div><!---row---> 
 
 </div><!---container--->
 
 <!-- Small modal -->


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Help?</h4>
      </div>
      <div class="modal-body">
     When the text is highlighted green the text is already copied to your clipboard.<br>
	 You can paste the text in an private mesage with the two buttons <strong>Ctrl + V</strong><br>
	 <br/>
	 When the text is NOT highlighted green OR if the copy button don't work!<br>
	 Simply right-click and select the text and copy with the two buttons <strong>Ctrl + C</strong><br><br>
	 Or use your left mouse button to copy the selected text.<br>
	 And your left mouse button to paste the again.<br><br>
	 <h4>Do Not close this page!</h4>
			   This will close the connection and remove the key!<br>
		       This key is valid Only for this page and as long you keep this page open.<br/>
		       <strong>Tip!</strong>
			   <br>Use the menu tabs on top to share your key and room URL<br/>
			   To your friends on social networks OR by email (if you already know this person).<br/>
			   The menu tab open in a new window!<br>
	 
	 
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>
</html>