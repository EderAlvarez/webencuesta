<?php
/////////////////////////////// WARNING do not edit below this line ///////////////////////////////
include ('inc.php');
function GetMatchingFiles ($matches) {
	if (!is_array ($matches)) $matches = array ($matches);
	$files = array();
	foreach ($matches as $match) {
		if (function_exists ("glob") && ($globfiles = glob ($match)) && is_array ($globfiles)) $files = array_merge ($files, $globfiles);
		else if (function_exists ('exec') && exec ('find ' . dirname ($match) . ' -type f | grep "' . str_replace ('*', '.*', str_replace ('.', '\.', basename ($match))) . '"', $findfiles) && is_array ($findfiles)) $files = array_merge ($files, $findfiles);
		else if (preg_match ('/\*/', $match) && ($dh = opendir ($filedir = dirname ($match)))) {
			$match = (str_replace ('*', '.*', str_replace ('.', '\.', "~$match~")));
			while (false!==($file=readdir($dh))) if (is_file($file="$filedir/$file") && preg_match ($match,$file)) array_push ($files, $file);
		}
		else array_push ($files, $match); 
	}
	return $files;
}
function IsMatchingFile ($matches, $file) {
	if (!is_array ($matches)) $matches = array ($matches);
	$n=0; foreach ($matches as $match) if (preg_match (str_replace ('*', '[^/\\\\]*', str_replace ('.', '\.', "~^$match$~")), $file)) $n++;
	return $n>0;
}
function GetImageFiles ($imagedir) { 
	$imageendings = array ('gif', 'jpg', 'jpeg', 'png');
	$a = array(); foreach ($imageendings as $ending) $a = array_merge ($a, GetMatchingFiles ("$imagedir*.$ending"));
	$images = array(); foreach ($a as $image) $images[$image] = preg_replace ("|^$imagedir|", '', $image);
	return $images;
}
function GetEditableAreas ($file) {
	$areas = array();
	$fc = file_get_contents ($file);
	preg_match_all ('/<!--ADMINCMS-START-([\w\d-]+)-->(.*)<!--ADMINCMS-END-->/sU', $fc, $matches, PREG_SET_ORDER);
	foreach ($matches as $m) array_push ($areas, array (ucwords (str_replace ('-', ' ', $m[1])), $m[2]));
	return $areas;
}
function SaveFile ($file, $areas, $backupdir='', $allowedfiles='', $includefiles='') {
	if (!$areas) return "There is no data to save";
	$fc = file_get_contents ($file);
	if (!$fc) return "Could not read the file $file";
	$parts = preg_split ('/(<!--ADMINCMS-[\w\d-]+-->)/', $fc, -1, PREG_SPLIT_DELIM_CAPTURE);
	if (count ($parts) != count ($areas) * 4 + 1) return "There are the wrong number of ADMINCMS tags in the file";
	$newcontents = array_shift ($parts);
	foreach ($areas as $i=>$area)
		$newcontents .= $parts[$i*4] . "\n" . trim (stripSlashes (preg_replace ("/\r\n?/", "\n", $areas[$i]))) . "\n" .
			$parts[$i*4 + 2] . $parts[$i*4+3];
	$backupminutes = 15; //only more than 15 $backupminutes ago
	if ($backupdir && is_file ($file) && ($backupstat = stat ($file)) && ($backupstat['mtime'] < time() - 60 * $backupminutes)) { 
		if (!is_dir ($backupdir)) {mkdir ($backupdir); chmod ($backupdir, 0777);}
		copy ($file, $backupfile = $backupdir . '/' . str_replace ('/', '-', $file) . '.' . date ('Y-m-d-Hi') . '.backup');
		if (file_exists ($backupfile)) chmod ($backupfile, 0666);
	}
	$fw = fopen ($file, 'w');
	if (!$fw) return "Could not write to the file $file. Please check the permissions.";
	fwrite ($fw, $newcontents); fclose ($fw);
	$othersaves = array(); 
	if ($includefiles && IsMatchingFile ($includefiles, $file)) {
		$newcontents = preg_replace ("/<!--ADMINCMS[^>]+-->/U", '', $newcontents);
		$lookfor = strtoupper (basename (preg_replace ('/\.\w+$/', '', $file)));
		foreach (GetMatchingFiles ($allowedfiles) as $otherfile) {
			if ($otherfile == $file) continue;
			if (!($fc = file_get_contents ($otherfile))) continue;
			if (strpos ($fc, "<!--ADMINCMSINCLUDE-START-$lookfor-->") === false) continue;
			if (!preg_match ("~(<!--ADMINCMSINCLUDE-START-$lookfor-->)(.*)(<!--ADMINCMSINCLUDE-END-->)~sU", $fc, $fcm)) continue;
			if (strpos ($fcm[2], '<!--ADMINCMS-')) continue;
			$fcnew = str_replace ($fcm[1].$fcm[2], $fcm[1].$newcontents, $fc);
			if ($fc == $fcnew) continue;
			if (! ($fw = fopen ($otherfile, 'w'))) continue;
			fwrite ($fw, $fcnew); fclose ($fw);
			$othersaves[] = $otherfile;
		} 
	} 
	return "<span class='label label-success'>File was saved successfully.</span>" . ($othersaves ? " <span class='label label-success'>This was also saved into " . join (', ', $othersaves) . '.' : '</span>');
}
function SaveImages ($imagedir) {
	$imageendings = array ('gif', 'jpg', 'jpeg', 'png'); $m = array();
	if (!is_dir ($imagedir)) {mkdir ($imagedir); chmod ($imagedir, 0777);}
	if (isset ($_POST['remove'])) foreach ($_POST['remove'] as $image) 
		if (preg_match ("~^$imagedir.+\." . join ('|', $imageendings) . '$~', $image)) {$m[] = "Removing $image"; unlink ($image);}
		else $m[] = "Cannot remove $image (perhaps because of the file ending)";
	foreach ($_FILES as $formfield=>$filedata) {
		if (!$filedata['size']) continue;
		$moveto = $imagedir . $filedata['name'];
		if ($filedata['error']) $m[] = "Could not upload $filedata[name] because of: $filedata[error]";
		else if (!preg_match ('~\.' . join ('|', $imageendings) . '$~', $filedata['name'])) $m[] = "Cannot upload $filedata[name] (wrong ending)";
		else {$m[] = "Saving $moveto"; move_uploaded_file ($filedata['tmp_name'], $moveto); chmod ($moveto, 0666);}
	}
	return join ('<br/>', $m);
}
function SavePages ($matches) {
	$m = array();
	if (isset ($_POST['remove'])) foreach ($_POST['remove'] as $page) 
		if (IsMatchingFile ($matches, $page) && unlink ($page)) $m[] = "Removing $page";
		else $m[] = "Cannot remove $page";
	if (($from = $_POST['pagecopyfrom']) && ($to = $_POST['pagecopyto'])) {
		$filedir = dirname ($to);
		if (!IsMatchingFile ($matches, $to)) $m[] = "Cannot copy to $to because it is not in the list of allowed files";
		else if (file_exists ($to)) $m[] = "Cannot copy to $to because the file already exists";
		else if (!is_dir ($filedir)) $m[] = "Cannot copy to $to because the directory $filedir does not exist";
		else if (!copy ($from, $to)) $m[] = "Cannot copy to $to, probably because of a permissions error";
		else $m[] = "<span class='label label-success'>Copying from $from to $to is done!</span>";
	}
	return join ('<br/>', $m);
}
function FormLogin ($username, $password) {
	if (!isset ($_SESSION)) session_start();
	if (isset ($_GET['logout'])) $_SESSION['AUTH_OK'] = '';
	$u = isset ($_POST['AUTH_USER']) ? $_POST['AUTH_USER'] : '';
	$p = isset ($_POST['AUTH_PW']) ? $_POST['AUTH_PW'] : '';
	if ($username == $u && $password == $p) {$_SESSION['AUTH_OK'] = $u; return;}
	if (isset ($_SESSION['AUTH_OK']) && $_SESSION['AUTH_OK']==$username) return;
	echo '<html><head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
	<link href="assets/signin.css" rel="stylesheet"><title>ADMIN</title></head>';
	echo '<body><div class="container"><form class="form-signin" method="post" action="http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '">';
	echo '<h4>ADMIN</h4><h3 class="form-signin-heading">Please sign in</h3>';
	if ($u || $p) echo '<div class="alert alert-danger">Your login details were incorrect, please try again <a class="btn btn-xs btn-danger" href="admin.php"><i class="fa fa-ban-circle"></i> Close</a></div>';
	else echo '<p>Please enter your login details below:</p>';
	echo '';
	echo 'User name: <input class="form-control" name="AUTH_USER" type="text" size="10" /><br/>';
	echo 'Password: <input class="form-control" name="AUTH_PW" type="password" size="10" /><br/>';
	echo '<button name="AUTH_LOGIN" type="submit" class="btn btn-lg btn-primary btn-block"><i class="fa fa-tower"></i> Login</button><a class="btn btn-lg btn-danger btn-block" href="index.php"><i class="fa fa-home"></i> Home</a></form></div></div></body></html>';
	exit;
}
function ProcessEditor ($imagedir) {
	if (isset ($_GET['editorimages'])) {
		$ei=''; foreach (GetImageFiles ($imagedir) as $src=>$image) $ei .= "\n,['$image', '$src']";
		header ("Content-type: application/javascript");
		echo 'var tinyMCEImageList = new Array (' . substr ($ei, 2) . ');';
		exit; //exit
	}
	if (!preg_match ('|EDITOR/(.*)$|', $_SERVER['REQUEST_URI'], $ed)) return;
	if (preg_match ('/css$/', $ed[1])) header ("Content-type: text/css"); 
	if (isset ($_SERVER['HTTP_IF_MODIFIED_SINCE'])) {
		header ("Expires: Sat, 6 Mar 1976 10:00:00 GMT");
		header ("Cache-Control: private, must-revalidate");
		header ("Pragma: cache");
		header ("HTTP/1.0 304 Not Modified");
		exit;
	}
	$contents = file_get_contents ('assets/jscripts/tiny_mce/themes/advanced/' . rawurldecode ($ed[1])); 
	header ("Last-Modified: " . gmdate ("D, d M Y H:i:s"));
	echo $contents; 
	exit;
}
function OutputPage ($allowedfiles, $backupdir='', $htmleditor='', $imagedir='', $includefiles='') {
	$me = basename ($_SERVER['PHP_SELF']);
	$areawidth = '130';
	$savepages = isset ($_POST['pagemanager']) ? $_POST['pagemanager'] : '';
	if ($savepages) {ob_start(); $spoutput = SavePages ($allowedfiles); $savepages = ob_get_contents() . $spoutput; ob_end_clean();}
	$filestoedit = GetMatchingFiles ($allowedfiles);
	$pagemanager = isset ($_GET['pagemanager']) ? $_GET['pagemanager'] : '';
	$imagemanager = isset ($_GET['imagemanager']) ? $_GET['imagemanager'] : '';
	$phpinfo = isset ($_GET['phpinfo']) ? $_GET['phpinfo'] : '';
	$editfile = isset ($_GET['file']) ? $_GET['file'] : '';
	if (!in_array ($editfile, $filestoedit)) $editfile = '';
	$isinclude = $editfile && IsMatchingFile ($includefiles, $editfile);
	$editareas = $editfile ? GetEditableAreas ($editfile) : array();
	$saveimages = isset ($_POST['imagemanager']) ? $_POST['imagemanager'] : '';
	if ($saveimages) $imagemanager = true;
	if ($savepages) $pagemanager = true;
	$savefile = isset ($_POST['file']) ? $_POST['file'] : '';
	if (!in_array ($savefile, $filestoedit)) $savefile = '';
	$saveareas = $savefile && isset ($_POST['areas']) ? $_POST['areas'] : array();
	$isauthlogin = !empty ($_SERVER['PHP_AUTH_USER']);
	$haseditor = null; if (is_array ($htmleditor)) {$haseditor = $htmleditor; $htmleditor = array_shift ($haseditor);}
	if ($haseditor) foreach ($haseditor as $hasi=>$hasc) $haseditor[$hasi] = strtolower ($hasc); 
?>
<?PHP
include('inc.php'); 
IF (ISSET($_POST["Submit"])) {
$string = '<?php 
////////////////////////////////////////////////////
///BOOTSTRAP 3 ADMIN CMS SPEEKY     ////////////////
////////////////////////////////////////////////////
$lang = "en";
$USERNAME = "'. $_POST['USERNAME']. '";
$PASSWORD = "'. $_POST['PASSWORD']. '";
$pubid = "'. $_POST['pubid']. '";
$ALLOWEDFILES = "'. $_POST['ALLOWEDFILES']. '";
$HTMLEDITOR = "'. $_POST['HTMLEDITOR']. '";
$BACKUPDIR = "'. $_POST['BACKUPDIR']. '";
$IMAGEDIR = "'. $_POST['IMAGEDIR']. '";
$siteurl = "'. $_POST['siteurl']. '";
$sitename = "'. $_POST['sitename']. '";
$slogan = "'. $_POST['slogan']. '";
$fbapikey = "'. $_POST['fbapikey']. '";
$mycam = "'. $_POST['mycam']. '";
$friendcam = "'. $_POST['friendcam']. '";
$bgimgrooms = "'. $_POST['bgimgrooms']. '";
$bgimgindex = "'. $_POST['bgimgindex']. '";
$indextextcolor = "'. $_POST['indextextcolor']. '";
$license = "'. $_POST['license']. '";
////// peer keys ///////
$peerkey01 = "'. $_POST['pk01']. '";
$peerkey02 = "'. $_POST['pk02']. '";
$peerkey03 = "'. $_POST['pk03']. '";
$peerkey04 = "'. $_POST['pk04']. '";
$peerkey05 = "'. $_POST['pk05']. '";
$peerkey06 = "'. $_POST['pk06']. '";
$peerkey07 = "'. $_POST['pk07']. '";
$peerkey08 = "'. $_POST['pk08']. '";
$peerkey09 = "'. $_POST['pk09']. '";
$peerkey10 = "'. $_POST['pk10']. '";

$peerkey11 = "'. $_POST['pk11']. '";
$peerkey12 = "'. $_POST['pk12']. '";
$peerkey13 = "'. $_POST['pk13']. '";
$peerkey14 = "'. $_POST['pk14']. '";
$peerkey15 = "'. $_POST['pk15']. '";
$peerkey16 = "'. $_POST['pk16']. '";
$peerkey17 = "'. $_POST['pk17']. '";
$peerkey18 = "'. $_POST['pk18']. '";
$peerkey19 = "'. $_POST['pk19']. '";
$peerkey20 = "'. $_POST['pk20']. '";

$peerkey21 = "'. $_POST['pk21']. '";
$peerkey22 = "'. $_POST['pk22']. '";
$peerkey23 = "'. $_POST['pk23']. '";
$peerkey24 = "'. $_POST['pk24']. '";
$peerkey25 = "'. $_POST['pk25']. '";
$peerkey26 = "'. $_POST['pk26']. '";
$peerkey27 = "'. $_POST['pk27']. '";
$peerkey28 = "'. $_POST['pk28']. '";
$peerkey29 = "'. $_POST['pk29']. '";
$peerkey30 = "'. $_POST['pk30']. '";

$peerkey31 = "'. $_POST['pk31']. '";
$peerkey32 = "'. $_POST['pk32']. '";
$peerkey33 = "'. $_POST['pk33']. '";
$peerkey34 = "'. $_POST['pk34']. '";
$peerkey35 = "'. $_POST['pk35']. '";
$peerkey36 = "'. $_POST['pk36']. '";
$peerkey37 = "'. $_POST['pk37']. '";
$peerkey38 = "'. $_POST['pk38']. '";
$peerkey39 = "'. $_POST['pk39']. '";
$peerkey40 = "'. $_POST['pk40']. '";

$peerkey41 = "'. $_POST['pk41']. '";
$peerkey42 = "'. $_POST['pk42']. '";
$peerkey43 = "'. $_POST['pk43']. '";
$peerkey44 = "'. $_POST['pk44']. '";
$peerkey45 = "'. $_POST['pk45']. '";
$peerkey46 = "'. $_POST['pk46']. '";
$peerkey47 = "'. $_POST['pk47']. '";
$peerkey48 = "'. $_POST['pk48']. '";
$peerkey49 = "'. $_POST['pk49']. '";
$peerkey50 = "'. $_POST['pk50']. '";
?>'; 
$fp = FOPEN("inc.php", "w");
FWRITE($fp, $string);
FCLOSE($fp); 
} 
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta http-equiv="cache-control" content="no-cache/">
<meta http-equiv="pragma" content="no-cache/">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<title>ADMIN</title>
<? if ($htmleditor) {$editorprefix = $htmleditor=='advanced' ? "$me/EDITOR/" : 'assets/jscripts/tiny_mce/themes/advanced/'; ?>
<script type="text/javascript" src="assets/jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">tinyMCE.init({mode : 'specific_textareas', language : 'en', editor_selector : 'editor', theme : '<?=$htmleditor?>', external_image_list_url : '<?=$me?>?editorimages=yes',
plugins : "autolink,lists,pagebreak,style,layer,table,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",
// Theme options
		theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,});
</script>
<?php } ?>
</head>
<body>
<div class="container">
<!--<div id="wrapper">--->
<h1>ADMIN</h1>
Hi, <?=$USERNAME?> Welcome to your admin - <a href="http://codecanyon.net/user/speeky" target="_blank">Support</a>
<!--div id="filelist"-->
<!--div-->
<h3><span class="fa fa-wrench"></span> All the Tools to edit your ads Files and PeerKeys</h3>
Here you find all the files which you are allowed to edit.
<p>
<?php	if (!$isauthlogin) { ?>
<a class="btn btn-danger" href="<?php echo $me?>?logout=yes"><span class="fa fa-log-out"></span> Log out</a><?php } ?>  <a class="btn btn-primary" href="admin.php"><span class="fa fa-lock"></span> Close all Open Tools</a> <a class="btn btn-info" href="admin.php"><span class="fa fa-refresh"></span> Refresh get your new settings</a> <a class="btn btn-success" href="index.php" target="_blank"><span class="fa fa-eye-open"></span> View site</a> <a class="btn btn-warning" href="<?php echo $me?>?phpinfo=yes"><span class="fa fa-th-list"></span> PHP info</a>
</p>
<!-- Nav tabs -->
<ul class="nav nav-tabs">
  <li><a href="#home" data-toggle="tab"><i class="fa fa-home"></i> Home</a></li>
  <li><a href="#settings" data-toggle="tab"><i class="fa fa-check"></i> Settings</a></li>
  <li><a href="#pages" data-toggle="tab"><i class="fa fa-edit"></i> Edit/View Pages</a></li>
  <li><a href="#images" data-toggle="tab"><i class="fa fa-image"></i> Images</a></li>
  <li><a href="#help" data-toggle="tab"><i class="fa fa-question-sign"></i> Help &amp; Info</a></li>
</ul>
<!-- Tab panes -->
<div class="tab-content">
  <div class="tab-pane active" id="home">
<strong>First:</strong> Go to settings, fill out the fields and check your settings! Be aware that user names and passwords are case-sensitive!
<br><br>
</div>
  <div class="tab-pane" id="pages"><br><br>Edit and or View pages<br><br><?php	$numfiles=0; foreach ($filestoedit as $listfile) if (basename ($me) != basename ($listfile)) {$numfiles++; ?>
<a href="<?php echo $listfile?>" class="viewlink btn btn-success" target="adminbootstrap3cmswindow">view page <span class="fa fa-eye-open"></span></a> <a class="btn btn-primary" href="<?php echo $me?>?file=<?php echo $listfile?>"><?php echo $listfile?> <span class="fa fa-edit">edit</span></a><br />
<?php	} ?>
<br><br><br><br>
</div>
  <div class="tab-pane" id="help">Here you find usefull information<br><br>
<p style="color:#FF0000;"><strong>WARNING!</strong> Do not use this software if you got this from warez sites, free dowload sites or forms etc. You will be a victim of hackers who modified this software!<br>
<u>Use only the legal safe version</u> You must have a license to use this software the legal and safe version can only be found on <strong>codecanyon.net</strong></p><br>
<h2>INFO</h2>
You can use the databaseles BOOTSTRAP 3 ADMIN CMS for the editeble elements in your page!<br>
You can also add and remove images video and if you upload your own images they wil apare in the dropdown menu of the editor!<br>
In the HTML mode of the editor you can also use <a href="http://getbootstrap.com" target="_blank">BOOTSTRAP 3</a> elements in your pages<br>
To make this Easyer you turn the editor OFF and use the HTML mode. (But make a backup first)<br><br>

If you don't want ads on your site just leave them blanc, if you use Google ads it is best to thurn off the editor to paste the code!<br>
The ad-files to edit are <strong>add1.php</strong> and <strong>add2.php</strong> just go to the tab [Edit/View Pages]<br>
</div>
<div class="tab-pane" id="settings">
  <h2><span class="fa fa-user"></span> Here your can set Your site settings</h2>
All fields with a star * are required and must be valid<br>
Please take a note of your admin login and keep this on a safe place!<br>
<h4>WARNING! Don't use Quotes ' OR " in the fields below!!!</h4>
<form action="" method="post" name="install" id="install">
    <input name="USERNAME" type="text" id="USERNAME" value="<?=$USERNAME?>" size="10">* Admin username<br>
    <input name="PASSWORD" type="text" id="PASSWORD" value="<?=$PASSWORD?>"size="10">* Admin password<br>
    <input name="sitename" type="text" id="sitename" value="<?=$sitename?>" size="40">* SiteName.com<br>
    <input name="siteurl" type="text" id="siteurl" value="<?=$siteurl?>" size="40">* Full url to the script No <strong>http://site.com/folder</strong> No end slash <strong>/</strong><br>
	<input name="slogan" type="text" id="slogan" value="<?=$slogan?>" size="40">* Slogan<br>
	<br>
	<input name="fbapikey" type="text" id="fbapikey" value="<?=$fbapikey?>" size="40">* fb api key (for the share button)<br>
	<input name="mycam" type="text" id="mycam" value="<?=$mycam?>" size="40">* My cam - eg img-circle  img-rounded<br>
	<input name="friendcam" type="text" id="friendcam" value="<?=$friendcam?>" size="40">* Friends Cam - eg img-circle  img-rounded<br>
	<input name="bgimgrooms" type="hidden" id="bgimgrooms" value="<?=$bgimgrooms?>" size="40">
	<input name="bgimgindex" type="hidden" id="bgimgindex" value="<?=$bgimgindex?>" size="40">
	<input name="indextextcolor" type="text" id="indextextcolor" value="<?=$indextextcolor?>" size="10">* index text color<br>
	<input name="license" type="text" id="license" value="<?=$license?>" size="10">* license Key (envato purchace code)<br>
	
    <input name="pubid" type="hidden" id="pubid" value="ra-5299994571c9c903" size="30">
    <input name="BACKUPDIR" type="hidden" id="BACKUPDIR" value="<?=$BACKUPDIR?>" size="30">
    <input name="IMAGEDIR" type="hidden" id="IMAGEDIR" value="<?=$IMAGEDIR?>" size="30">
    <input name="ALLOWEDFILES" type="hidden" id="ALLOWEDFILES" value="<?=$ALLOWEDFILES?>"size="30"><br>
    <h2><span class="fa fa-edit"></span> EDITOR</h2>
    The Editor is now set to: <span class="label label-primary"><input type="hidden" name="HTMLEDITOR" id="HTMLEDITOR" value="<?=$HTMLEDITOR?>" checked/>Editor <?=$HTMLEDITOR?></span><br> 
    <span class="label label-info"><input type="radio" name="HTMLEDITOR" id="HTMLEDITOR" value="advanced"/>Advanced</span> -OR- <span class="label label-info"><input type="radio" name="HTMLEDITOR" id="HTMLEDITOR" value="off"/>OFF (HTML mode)</span>
    <br/><hr>
	<div class="container">
	<div class="row">
	<div class="col-md-4">
	How to get your peerkeys?<br>
	Jus create an account and get your own peerkeys<br>
	when you create the keys the oldest (first one) is on top!<br>
	the one you create next is there below the last one is always at the botom.<br><br>
	<a class="btn btn-warning" href="http://peerjs.com/peerserver" target="_blank">Click here get Your Keys</a>
	</div>
	
	<div class="col-md-4">
	01-10<br>
	<input name="pk01" type="text" id="pk01" value="<?=$peerkey01?>" size="20"> 01<br>
	<input name="pk02" type="text" id="pk02" value="<?=$peerkey02?>" size="20"> 02<br>
	<input name="pk03" type="text" id="pk03" value="<?=$peerkey03?>" size="20"> 03<br>
	<input name="pk04" type="text" id="pk04" value="<?=$peerkey04?>" size="20"> 04<br>
	<input name="pk05" type="text" id="pk05" value="<?=$peerkey05?>" size="20"> 05<br>
	<input name="pk06" type="text" id="pk06" value="<?=$peerkey06?>" size="20"> 06<br>
	<input name="pk07" type="text" id="pk07" value="<?=$peerkey07?>" size="20"> 07<br>
	<input name="pk08" type="text" id="pk08" value="<?=$peerkey08?>" size="20"> 08<br>
	<input name="pk09" type="text" id="pk09" value="<?=$peerkey09?>" size="20"> 09<br>
	<input name="pk10" type="text" id="pk10" value="<?=$peerkey10?>" size="20"> 10<br>
	<br>
	</div>
	
	<div class="col-md-4">
	10-20<br>
	<input name="pk11" type="text" id="pk11" value="<?=$peerkey11?>" size="20"> 11<br>
	<input name="pk12" type="text" id="pk12" value="<?=$peerkey12?>" size="20"> 12<br>
	<input name="pk13" type="text" id="pk13" value="<?=$peerkey13?>" size="20"> 13<br>
	<input name="pk14" type="text" id="pk14" value="<?=$peerkey14?>" size="20"> 14<br>
	<input name="pk15" type="text" id="pk15" value="<?=$peerkey15?>" size="20"> 15<br>
	<input name="pk16" type="text" id="pk16" value="<?=$peerkey16?>" size="20"> 16<br>
	<input name="pk17" type="text" id="pk17" value="<?=$peerkey17?>" size="20"> 17<br>
	<input name="pk18" type="text" id="pk18" value="<?=$peerkey18?>" size="20"> 18<br>
	<input name="pk19" type="text" id="pk19" value="<?=$peerkey19?>" size="20"> 19<br>
	<input name="pk20" type="text" id="pk20" value="<?=$peerkey20?>" size="20"> 20<br>
	<br>
	</div>
	
	<div class="col-md-4">
	21-30<br>
	<input name="pk21" type="text" id="pk21" value="<?=$peerkey21?>" size="20"> 21<br>
	<input name="pk22" type="text" id="pk22" value="<?=$peerkey22?>" size="20"> 22<br>
	<input name="pk23" type="text" id="pk23" value="<?=$peerkey23?>" size="20"> 23<br>
	<input name="pk24" type="text" id="pk24" value="<?=$peerkey24?>" size="20"> 24<br>
	<input name="pk25" type="text" id="pk25" value="<?=$peerkey25?>" size="20"> 25<br>
	<input name="pk26" type="text" id="pk26" value="<?=$peerkey26?>" size="20"> 26<br>
	<input name="pk27" type="text" id="pk27" value="<?=$peerkey27?>" size="20"> 27<br>
	<input name="pk28" type="text" id="pk28" value="<?=$peerkey28?>" size="20"> 28<br>
	<input name="pk29" type="text" id="pk29" value="<?=$peerkey29?>" size="20"> 29<br>
	<input name="pk30" type="text" id="pk30" value="<?=$peerkey30?>" size="20"> 30<br>
	<br>
	</div>
	
	<div class="col-md-4">
	31-40<br>
	<input name="pk31" type="text" id="pk31" value="<?=$peerkey31?>" size="20"> 31<br>
	<input name="pk32" type="text" id="pk32" value="<?=$peerkey32?>" size="20"> 32<br>
	<input name="pk33" type="text" id="pk33" value="<?=$peerkey33?>" size="20"> 33<br>
	<input name="pk34" type="text" id="pk34" value="<?=$peerkey34?>" size="20"> 34<br>
	<input name="pk35" type="text" id="pk35" value="<?=$peerkey35?>" size="20"> 35<br>
	<input name="pk36" type="text" id="pk36" value="<?=$peerkey36?>" size="20"> 36<br>
	<input name="pk37" type="text" id="pk37" value="<?=$peerkey37?>" size="20"> 37<br>
	<input name="pk38" type="text" id="pk38" value="<?=$peerkey38?>" size="20"> 38<br>
	<input name="pk39" type="text" id="pk39" value="<?=$peerkey39?>" size="20"> 39<br>
	<input name="pk40" type="text" id="pk40" value="<?=$peerkey40?>" size="20"> 40<br>
	<br>
	</div>
	
	<div class="col-md-4">
	41-50<br>
	<input name="pk41" type="text" id="pk41" value="<?=$peerkey41?>" size="20"> 41<br>
	<input name="pk42" type="text" id="pk42" value="<?=$peerkey42?>" size="20"> 42<br>
	<input name="pk43" type="text" id="pk43" value="<?=$peerkey43?>" size="20"> 43<br>
	<input name="pk44" type="text" id="pk44" value="<?=$peerkey44?>" size="20"> 44<br>
	<input name="pk45" type="text" id="pk45" value="<?=$peerkey45?>" size="20"> 45<br>
	<input name="pk46" type="text" id="pk46" value="<?=$peerkey46?>" size="20"> 46<br>
	<input name="pk47" type="text" id="pk47" value="<?=$peerkey47?>" size="20"> 47<br>
	<input name="pk48" type="text" id="pk48" value="<?=$peerkey48?>" size="20"> 48<br>
	<input name="pk49" type="text" id="pk49" value="<?=$peerkey49?>" size="20"> 49<br>
	<input name="pk50" type="text" id="pk50" value="<?=$peerkey50?>" size="20"> 50<br>
	<br>
	</div>
	

	</div>
	</div>
	<br/><hr>
    <input class="btn btn-success" type="submit" name="Submit" value=" Edit settings "> <input class="btn btn-danger"type="button" value=" Cancel " onClick="window.location.reload()">
  <br/><br/><br/>
</form>
<br><br><br><br><br><br>
</div>
<div class="tab-pane" id="images">
<h2 class="otheractions"><span class="fa fa-cog"></span> Add & Remove Images</h2>
Here your can add remove images you can use them later in the editeble areas.<br/><br/>
<?php	if ($imagedir) { ?><a class="btn btn-primary" href="<?php echo $me?>?imagemanager=yes">Remove & add images</a> <?php } //a link to the image manager ?>
<br><br><br><br><br><br>
</div>
</div>
<div id="editarea">
<?php	if ($phpinfo) phpinfo(); ?>
<?php	if ($savefile) { ?>
<br><br><div class="alert alert-success"><h2>Saving the file <?php echo $savefile?></h2>
<p>Saving the file <a class="btn btn-primary" href="<?php echo $me?>?file=<?php echo $savefile?>"><?php echo $savefile?> <span class="fa fa-floppy-saved"></span> Edit</a>
<a class="btn btn-primary" href="<?php echo $savefile?>" target="_blank">view page <span class="fa fa-eye-open"></span></a><br>If Any errors or success in savings! this will appear here belowe...</p>
<p><b><?php echo  SaveFile ($savefile, $saveareas, $backupdir, $allowedfiles, $includefiles) ?></b></p></div>
<?php	}  ?>
<?php	if ($editfile) {  ?>
<h2>Editing the <?php echo $isinclude ? 'include' : '' ?> file <?php echo  $editfile?></h2>
<p>Please edit the <?php echo $htmleditor ? 'text' : 'HTML'?> in the area below and then click Save changes.
<?php if ($isinclude) { ?><br/>This is an include file so changes will be saved to all other editable files as well.<?php } ?>
<form method="post" action="<?php echo $me?>">
<input name="file" type="hidden" value="<?php echo $editfile?>" />
<?php		if (!$editareas) echo "<div class='alert alert-danger'>Sorry but $editfile is not editable <a class='btn btn-danger' href='admin.php'>Close X</a>"; ?>
<?php		foreach ($editareas as $area) {$output = $area[1]; ?>
<?php 			$class = preg_match ('/<title|<meta/i', $output) ? '' : 'editor'; ?>
<?php 			if (is_array ($haseditor) && !in_array (strtolower ($area[0]), $haseditor)) $class = ''; ?>
<?php			$numlines = $htmleditor&&$class ? 20 : substr_count (wordwrap ($output, $areawidth), "\n"); ?>
<h3><?php echo $area[0]?></h3>
<textarea name="areas[]" rows="<?php echo  max ($numlines, 5) ?>" cols="<?php echo $areawidth?>" class="<?php echo $class?>"><?php echo $output?></textarea>
<?php		} ?>
<?php		if ($editareas) echo '<br/><button type="submit" class="button btn btn-success" value="Save changes"/>Save changes <span class="fa fa-floppy-disk"></span></button> <a class="btn btn-danger" href="admin.php">Cancel</a><br/><br/><br/><br/><br/><br/>'; ?>
</form>
<?php	}  ?>
<?php	if ($saveimages) { ?>
<br><br><div class="alert alert-success"><h2>Saving images</h2>
<p>Saving the images. Any errors in saving will appear here...</p>
<p><b><?php echo  SaveImages ($imagedir) ?></b> <span class="fa fa-floppy-saved"></span> Done!</p></div>
<?php	} ?>
<?php	if ($imagemanager) {  ?>
<h2><span class="fa fa-picture"></span> Manage images</h2>
<p>Use the checkboxes below to remove images and the buttons to view images<br/>This also upload images to <?php echo $imagedir?> all the images can than be used and selected in the text editor (dropdown menu).</p>
<form method="post" action="<?php echo $me?>" enctype="multipart/form-data">
<input name="imagemanager" type="hidden" value="yes" />

<?php	foreach (GetImageFiles ($imagedir) as $src=>$image) { ?>
<img src="<?php echo $src?>"><br><span><input type="checkbox" name="remove[]" value="<?php echo $src?>"> remove? -OR- <a class="btn btn-primary btn-xs" href="<?php echo $src?>" target="adminbootstrap3cms_view">view <span class="fa fa-eye-open"></span> | <?php echo $image?></a></span><hr />
<?php	} ?>
<br /><br />Upload a new image: <input type="file" name="newimage1" size="20" /><br /><br />

<button type="submit" class="button btn btn-success" value="Save changes"/>Save changes <span class="fa fa-floppy-disk"></span></button> <a class="btn btn-danger" href="admin.php">Cancel</a>
</form>
<?php	} ?>
<?php	if ($savepages) {  ?>
<br><br><div class="alert alert-success"><h2>Saving</h2>
<p>Removing. Any errors in saving will appear here...</p>
<p><b><?php echo  $savepages ?></b> <span class="fa fa-floppy-saved"></span> Done!</p></div>
<?php	} ?>
<?php	if ($pagemanager) { ?>
<form method="post" action="<?php echo $me?>">
<input name="pagemanager" type="hidden" value="yes" />
<h2><span class="fa fa-file"></span> pages</h2>
<p>Use.<br />
<span class="label label-danger"> *WARNING*</span><br>
You may need this files<br>
</p>
<?php	$filestocopy=''; foreach ($filestoedit as $listfile) if (basename ($me) != basename ($listfile)) {$filestocopy.= "<option>$listfile"; ?>
<input type="checkbox" name="remove[]" value="<?php echo $listfile?>"> remove? <?php echo $listfile?> <br />
<?php	} ?>
<br />
<h2><span class="fa fa-transfer"></span>template</h2>
Just Select stay as it is!<br />
Copy a page <select name="pagecopyfrom"><option>choose one<?php echo $filestocopy?></select> copy to <input type="text" placeholder="mynewpage.php" name="pagecopyto" size="20" /><br />
Remember eg. <code>page.php</code><br /><br />
<button type="submit" class="button btn btn-success" value="Save changes"/>Save changes <span class="fa fa-floppy-disk"></span></button> <a class="btn btn-danger" href="admin.php">Cancel</a>
</form>
<?php	} ?>
<!--/div--->
<div class="clear"></div>
<!--</div>-->
<? include ('settings/adfooter.php');?>
</div>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>
</body>
</html>
<?php	
} 



/////////////////////////////// START ADMIN CMS ///////////////////////////////
ini_set ('display_errors', 1); error_reporting (E_ALL);
if ($USERNAME) FormLogin ($USERNAME, $PASSWORD);
ProcessEditor ($IMAGEDIR);
OutputPage ($ALLOWEDFILES, $BACKUPDIR, $HTMLEDITOR, $IMAGEDIR);
?>