<footer>
<span class="label label-success"> &copy; <? echo date ('Y');?> - <?=$sitename;?> - <?=$slogan;?></span>
      </footer>
	  <br/><br/><br/><br/>