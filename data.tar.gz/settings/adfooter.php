<br /><br /><br /><br /><hr />
<center><p style=" font-size:10px;">&copy; <? echo date ('Y');?> Speeky</p></center>