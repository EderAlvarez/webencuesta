<div class="">
<center>
<strong>Tell your friends about us <i class="fa fa-thumbs-o-up fa-lg"></i></strong>
<br/>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=<?=$fbapikey;?>&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-like" data-href="<?=$siteurl;?>" data-layout="box_count" data-action="like" data-show-faces="false" data-share="false" style="vertical-align:top;zoom:1;*display:inline"></div>

<a href="https://twitter.com/share" class="twitter-share-button" data-url="<?=$siteurl;?>" data-lang="en" data-related="anywhereTheJavascriptAPI" data-count="vertical">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<script src="//platform.linkedin.com/in.js" type="text/javascript">
  lang: en_US
</script>
<script type="IN/Share" data-url="<?=$siteurl;?>" data-counter="top"></script>

<script src="https://apis.google.com/js/platform.js" async defer>
  {lang: 'en'}
</script>
<div class="g-plusone" data-size="tall"></div>
</center>
</div>