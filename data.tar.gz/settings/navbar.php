<link href="../css/navbar-custom.css" rel="stylesheet">
<style>
/*
.navbar .divider-vertical {
height: 30px;
margin: 10 9px;
border-right: 1px dotted #00D619;
border-left: 1px dotted #00D619;
}

.navbar-inverse .divider-vertical {
border-right-color: #222222;
border-left-color: #111111;
}

@media (max-width: 767px) {
.navbar-collapse .nav > .divider-vertical {
    display: none;
  }
}*/
</style>
<nav class="navbar navbar-custom" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand"><i class="fa fa-lg fa-video-camera"></i> <?=$sitename;?></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
	  <li class="divider-vertical"></li>
        <li><a href="http://facebook.com" target="_blank"><i class="fa fa-lg fa-facebook-square"></i> Facebook</a></li>
		<li class="divider-vertical"></li>
        <li><a href="http://twitter.com" target="_blank"><i class="fa fa-lg fa-twitter-square"></i> Twitter</a></li>
		<li class="divider-vertical"></li>
		<li><a href="http://google.com" target="_blank"><i class="fa fa-lg fa-google-plus-square"></i> Google+</a></li>
		<li class="divider-vertical"></li>
		<li><a href="http://linkedin.com" target="_blank"><i class="fa fa-lg fa-linkedin-square"></i> Linkedin</a></li>
		<li class="divider-vertical"></li>
		<li><a href="http://msn.com" target="_blank"><i class="fa fa-lg fa-windows"></i> MSN Outlook</a></li>
		<li class="divider-vertical"></li>
		<li><a href="https://login.yahoo.com" target="_blank"><i class="fa fa-lg fa-yahoo"></i> Yahoo mail</a></li>
		<li class="divider-vertical"></li>
       <!--- <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-check-square-o"></i> More tools <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
		    <li><a href="" target="_blank">item 1</a></li>
            <li><a href="" target="_blank">item 2</a></li>
            <li><a href="" target="_blank">item 3</a></li>
            <li><a href="" target="_blank">item 4</a></li>
            <li class="divider"></li>
            <li><a href="" target="_blank">item 5</a></li>
          </ul>
        </li>---->
      </ul>
     <!--- <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Friends enail">
        </div>
        <button type="submit" class="btn btn-info"><i class="fa fa-lg fa-envelope-o"></i> Send by Email</button>
      </form> --->
      <ul class="nav navbar-nav navbar-right">
        <!---<li><a href="http://codecanyon.net/item/facebook-attention-share-generator-viral-tool/8787891?ref=speeky" target="_blank"><i class="fa fa-lg fa-cloud-download"></i> Download this script Here!</a></li>--->
       <!--- <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-thumbs-o-up"></i> More Hot items <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
		   <li><a href="http://codecanyon.net/item/sales-and-affiliate-booster-pro/6426581?ref=speeky" target="_blank">Sales and Affiliate Booster pro</a></li>
            <li><a href="http://codecanyon.net/item/gamezone-flash-and-html5-stand-alone-game-site/7787579?ref=speeky" target="_blank">GameZone HTML5 & Flash Games</a></li>
            <li><a href="http://codecanyon.net/item/powerful-viral-image-search-and-share-engine/6953127?ref=speeky" target="_blank">Viral Image Search and Share</a></li>
            <li><a href="http://codecanyon.net/item/soundcloud-2-mp3-converter-and-3mp-to-mp3player/4533338?ref=speeky" target="_blank">SoundCloud 2 Mp3 Converter and 3mp to mp3-player</a></li>
            <li><a href="http://codecanyon.net/item/soundcloud-to-mp3-viral-social-share-reward/7868861?ref=speeky" target="_blank">Soundcloud to MP3 and Viral share gate</a></li>
            <li><a href="http://codecanyon.net/item/facebook-attention-share-generator-viral-tool/8787891?ref=speeky" target="_blank">Facebook attention generator</a></li>
            <li><a href="http://codecanyon.net/item/sales-and-affiliate-booster-pro/6426581?ref=speeky" target="_blank">Sales and Affiliate Booster pro</a></li>
            <li><a href="http://codecanyon.net/item/social-image-share-viral-traffic/5360664?ref=speeky" target="_blank">Social Image Share viral traffic</a></li>
            <li><a href="http://codecanyon.net/item/facebook-comments-and-likebox-pimper/5992480?ref=speeky" target="_blank">Facebook Comments and LikeBox Pimper</a></li>
            <li class="divider"></li>
            <li><a href="http://codecanyon.net/user/speeky/portfolio?ref=speeky" target="_blank">See all Items here!</a></li>
          </ul>
        </li>
      </ul> --->
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!--end nav bar ---->