<?php 
////////////////////////////////////////////////////
///BOOTSTRAP 3 ADMIN CMS SPEEKY     ////////////////
////////////////////////////////////////////////////
$lang = "en";
$USERNAME = "admin";
$PASSWORD = "admin";
$pubid = "ra-5299994571c9c903";
$ALLOWEDFILES = "*.php";
$HTMLEDITOR = "off";
$BACKUPDIR = "editorbackup/";
$IMAGEDIR = "editorimg/";
$siteurl = "http://vi2u.com";
$sitename = "Vi2u.com";
$slogan = "Free One on One - Face TO Face - Private Video Chat";
$fbapikey = "1595095930717002";
$mycam = "img-circle";
$friendcam = "img-circle";
$bgimgrooms = "images/pixel.png";
$bgimgindex = "images/pixel.png";
$indextextcolor = "#009900";
$license = "Valid-license-code-here!";
////// peer keys ///////
$peerkey01 = "xxxxx";
$peerkey02 = "xxxxx";
$peerkey03 = "xxxxx";
$peerkey04 = "xxxxx";
$peerkey05 = "xxxxx";
$peerkey06 = "xxxxx";
$peerkey07 = "xxxxx";
$peerkey08 = "xxxxx";
$peerkey09 = "xxxxx";
$peerkey10 = "xxxxx";

$peerkey11 = "xxxxx";
$peerkey12 = "xxxxx";
$peerkey13 = "xxxxx";
$peerkey14 = "xxxxx";
$peerkey15 = "xxxxx";
$peerkey16 = "xxxxx";
$peerkey17 = "xxxxx";
$peerkey18 = "xxxxx";
$peerkey19 = "xxxxx";
$peerkey20 = "xxxxx";

$peerkey21 = "xxxxx";
$peerkey22 = "xxxxx";
$peerkey23 = "xxxxx";
$peerkey24 = "xxxxx";
$peerkey25 = "xxxxx";
$peerkey26 = "xxxxx";
$peerkey27 = "xxxxx";
$peerkey28 = "xxxxx";
$peerkey29 = "xxxxx";
$peerkey30 = "xxxxx";

$peerkey31 = "xxxxx";
$peerkey32 = "xxxxx";
$peerkey33 = "xxxxx";
$peerkey34 = "xxxxx";
$peerkey35 = "xxxxx";
$peerkey36 = "xxxxx";
$peerkey37 = "xxxxx";
$peerkey38 = "xxxxx";
$peerkey39 = "xxxxx";
$peerkey40 = "xxxxx";

$peerkey41 = "xxxxx";
$peerkey42 = "xxxxx";
$peerkey43 = "xxxxx";
$peerkey44 = "xxxxx";
$peerkey45 = "xxxxx";
$peerkey46 = "xxxxx";
$peerkey47 = "xxxxx";
$peerkey48 = "xxxxx";
$peerkey49 = "xxxxx";
$peerkey50 = "xxxxx";
?>