<center>
<!--ADMINCMS-START-ADD-1-250x250-->
<!--- here belowe your ad 250x250 --->

<!--ADMINCMS-END-->
</center>