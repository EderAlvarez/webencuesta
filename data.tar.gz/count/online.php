<?
// Timeout - After this time the users will
// be deleted (in minutes)
$timer = 60;

// Name of the file where all the data, about
// the user's activity will be saved
$filename = "count/online.txt";

if (!isset($datei)) {
    $datei = $filename;
}

$time = @time();
$ip = $_SERVER['REMOTE_ADDR'];
$string = "$ip|$time\n";
$a = fopen("$filename", "a+");
fputs($a, $string);
fclose($a);

$timeout = time()-(60*$timer);

$all = "";
$i = 0;
$datei = file($filename);
for ($num = 0; $num < count($datei); $num++) {
    $pieces = explode("|",$datei[$num]);

    if ($pieces[1] > $timeout) {
        $all .= $pieces[0];
        $all .= ",";
    }

    $i++;
}

$all = substr($all,0,strlen($all)-1);
$arraypieces = explode(",",$all);
$useronline = count(array_flip(array_flip($arraypieces)));

// display how many people where active within $timeout
echo $useronline;

// Delete
$dell = "";
for ($numm = 0; $numm < count($datei); $numm++) {
    $tiles = explode("|",$datei[$numm]);
    if ($tiles[1] > $timeout) {
        $dell .= "$tiles[0]|$tiles[1]";
    }
}

if (!$datei) $datei = dirname(__FILE__)."$filename";

$time = @time();
$ip = $_SERVER['REMOTE_ADDR'];
$string = "$dell";
$a = fopen("$filename", "w+");
fputs($a, $string);
fclose($a);
?>