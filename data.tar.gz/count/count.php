<?php  $File = "count/counter.txt";  //This is the text file we keep our count in, that we just made   
$handle = fopen($File, 'r+') ;  //Here we set the file, and the permissions to read plus write   
$data = fread($handle, 512) ;  //Actully get the count from the file   
$count = $data + 1;  //Add the new visitor to the count   
print "Already trusted by <strong>".number_format($count)."</strong> Active users and Counting. ";  //Prints the count on the page   
fseek($handle, 0) ;  //Puts the pointer back to the begining of the file   
fwrite($handle, $count) ;  //saves the new count to the file   
fclose($handle) ;  //closes the file  
//$callsz = $count / 2;
//print "<small>Total calls made: <strong>".number_format($callsz)."</strong></small>";
?>