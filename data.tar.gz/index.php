<? include ('inc.php');?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?=$sitename;?> <?=$slogan;?> Video Chat Cam Rooms">
    <meta name="author" content="<?=$sitename;?> <?=$slogan;?> Video Chat Cam Rooms">
    <link rel="icon" type="image/png" href="favicon.png">

    <title><?=$sitename;?> Free Video Chat Cam Rooms</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="css/carousel.css" rel="stylesheet">
	<link href="css/navbar-custom.css" rel="stylesheet">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	<style type="text/css">
	body,td,th {
	color: <?=$indextextcolor;?>;
}
body {
	background-image: url(<?=$bgimgindex;?>);
	background-repeat: repeat;
}
/*
.navbar .divider-vertical {
height: 50px;
margin: 0 0px;
border-right: 1px dotted #00D619;
border-left: 1px dotted #00D619;
}

.navbar-inverse .divider-vertical {
border-right-color: #222222;
border-left-color: #111111;
}

@media (max-width: 767px) {
.navbar-collapse .nav > .divider-vertical {
    display: none;
  }
}*/
</style>
  </head>
<!-- NAVBAR
================================================== -->
  <body>
    <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-custom navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="<?=$siteurl;?>"><i class="fa fa-lg fa-video-camera"></i> <?=$sitename;?></a>
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
			  <li class="divider-vertical"></li>
                <li class="active"><a href="<?=$siteurl;?>">Home</a></li>
				<li class="divider-vertical"></li>
               <!-- <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>--->
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-comments"></i> Cam Rooms <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="private/room01.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 01 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room02.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 02 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room03.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 03 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room04.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 04 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room05.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 05 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room06.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 06 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room07.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 07 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room08.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 08 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room09.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 09 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room10.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 10 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                  </ul>
                </li>
				<li class="divider-vertical"></li>
				 <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-comments"></i> Cam Rooms <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="private/room11.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 11 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room12.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 12 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room13.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 13 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room14.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 14 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room15.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 15 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room16.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 16 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room17.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 17 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room18.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 18 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room19.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 19 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room20.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 20 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					
                  </ul>
                </li>
				<li class="divider-vertical"></li>
				<li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-comments"></i> Cam Rooms <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="private/room21.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 21 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room22.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 22 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room23.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 23 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room24.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 24 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room25.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 25 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room26.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 26 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room27.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 27 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room28.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 28 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room29.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 29 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room30.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 30 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                  </ul>
                </li>
				
				<li class="divider-vertical"></li>
				 <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-comments"></i> Cam Rooms <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="private/room31.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 31 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room32.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 32 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room33.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 33 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room34.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 34 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room35.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 35 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room36.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 36 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room37.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 37 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room38.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 38 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room39.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 39 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room40.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 40 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                  </ul>
                </li>
				<li class="divider-vertical"></li>
				
				 <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lg fa-comments"></i> Cam Rooms <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="private/room41.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 41 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room42.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 42 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                    <li><a href="private/room43.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 43 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room44.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 44 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room45.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 45 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room46.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 46 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room47.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 47 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room48.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 48 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room49.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 49 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
					<li><a href="private/room50.php" target="_blank"><i class="fa fa-lg fa-comments"></i> Room 50 <i class="fa fa-lg fa-microphone"></i> <i class="fa fa-lg fa-video-camera"></i></a></li>
                  </ul>
                </li>
				<li class="divider-vertical"></li>
				<li><a href="" data-toggle="modal" data-target=".bs-example-modal-sm"><i class="fa fa-lg fa-share-alt-square"></i> Share Love</a></li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>

<!--ADMINCMS-START-CAROUSEL-->
    <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="item active">
          <img src="images/slide1.jpg" alt="No Need to Sign up!">
          <div class="container">
            <div class="carousel-caption">
			 
              <h1><i class="fa fa-lg fa-video-camera"></i> <?=$sitename;?> FREE Private Webcam chat</h1>
              <strong><p>We Don't Need and we Don't Want your email<br/>
			  This way You know our service is 100% Spam Free!<br/>
			  Our site is not connected to any database,<br/>
			  There is noting to store Anyway!</p></strong>
			  
			  <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal1"><i class="fa fa-lg fa-sign-in"></i> NO Need to Sign up! Direct access</button>
            </div>
          </div>
        </div>
        <div class="item">
          <img src="images/slide2.jpg" alt="No Software install">
          <div class="container">
            <div class="carousel-caption">
			 
              <h1><i class="fa fa-lg fa-video-camera"></i> <?=$sitename;?> FREE Private Webcam chat</h1>
              <strong><p>No software to install, The only software you need is your browser.<br/>
			  This way it's 100% Risk Free to use.<br/>
			  We cannot modify, put adware or popups in your browser or system.<br/>
			  WebRTC is P2P communication safe & encripted, Not even we can Spy on You</p></strong>
			  
              <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal1"><i class="fa fa-lg fa-cogs"></i> NO Software to install</button>
            </div>
          </div>
        </div>
        <div class="item">
          <img src="images/slide3.jpg" alt="No appi download">
          <div class="container">
            <div class="carousel-caption">
			
              <h1><i class="fa fa-lg fa-video-camera"></i> <?=$sitename;?> FREE Private Webcam chat</h1>
              <strong><p>It's Just a Great place to meet and Talk to People... World Wide!<br/>
			  Found someone on a dating site or social network? you think you like!<br/>
			  "Meet each other here" and Talk face to face, And find out!<br/>
			  You can talk Face to Face without any Risk to get Spammed or scammed<br/>
			  Your identity email and privacy is safe as long as You don't give it Away!</p></strong>
			 
              <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal1"><i class="fa fa-lg fa-android"></i> NO appis to download</button>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev"><img src="images/li.png"></a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next"><img src="images/re.png"></a>
    </div><!-- /.carousel -->
<!--ADMINCMS-END-->


    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->
<!--ADMINCMS-START-MAIN-->
    <div class="container marketing">

      <!-- Three columns of text below the carousel -->
      <div class="row">
	  <div class="col-lg-12">
	      <div class="panel panel-default">
              <div class="panel-body">
		
	      Yes! You never know Who is behind that cute nice photo on a social network OR dating site! And You're also not the first or last that can be scammed on sites like that!<br/>
		  Sometimes you don't wanna give your Skype, MSN or Email before you know that person better! And here's where <?=$sitename;?> comes in.<br/>
		  It's realy hard to fake with a webcam, Here you can check if the person is real OR fake!<br/>
		 
		      </div>
		  </div>
	  </div>
        <div class="col-lg-4">
          <img class="img-circle img-thumbnail" src="images/s1.jpg" alt="" style="width: 140px; height: 140px;">
          <h2>Easier Than, Skype!</h2>
          <strong><p>It's not only Easier but also safer and faster there's no need to store passwords or enter your email, it's P2P browser to browser!<br/>
		  WebRTC works on your PC, Laptop, Tablet and SmartPhone by using latest Google, Mozilla and Opera browsers</p></strong>
          <p><a class="btn btn-success" href="#" role="button" data-toggle="modal" data-target="#myModal1">More details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle img-thumbnail" src="images/s2.jpg" alt="" style="width: 140px; height: 140px;">
          <h2>100% FREE NO Sign Up!</h2>
          <strong><p>WebRTC is free, and enables web browsers Google, Mozilla and Opera with Real-Time high quality Communications via (RTC) capabilities Just using simple JavaScript. The WebRTC components have been optimized to the best Safe & Secure serve for this purpose. </p></strong>
          <p><a class="btn btn-success" href="#" role="button" data-toggle="modal" data-target="#myModal1">More details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle img-thumbnail" src="images/s3.jpg" alt="" style="width: 140px; height: 140px;">
          <h2>100% Safe & Secure</h2>
          <strong><p>Our mission: To bring high quality, 100% Safe & Secure RTC applications to your browser via simple JavaScript APIs and HTML5.<br/>
           WebRTC is supported by Google, Mozilla and Opera. The WebRTC page is maintained by the Google Chrome team.</p></strong>
          <p><a class="btn btn-success" href="#" role="button" data-toggle="modal" data-target="#myModal1">More details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->


      <!-- START THE FEATURETTES -->

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7">
          <h2 class="featurette-heading">
		  FireFox TO Chrome.<br>
		  <span class="text-muted">This will blow your mind.</span><i class="fa fa-lg fa-smile-o"></i></h2>
          <p class="lead">(WebRTC) Inspiring the future and connecting the world for FREE.<br/>
		  Nothing to install <?=$sitename;?> runs direct in your browser.<br/>
		  <strong>Chrome, Mozilla Firefox and Opera</strong> “all you need is a webcam”<br/>
		  You can make long distance video calls without time any limits.<br/>
		  Safari and IE does not support WebRTC (jet!)<br/>
          Our goal is to bring Joy, Fun while keep things safe & free.</p>
        </div>
        <div class="col-md-5">
          <iframe width="500" height="400" src="//www.youtube.com/embed/MsAWR_rJ5n8?rel=0" frameborder="0" allowfullscreen></iframe>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-5">
          <img class="featurette-image img-responsive img-thumbnail" src="images/a1.jpg" alt="">
        </div>
        <div class="col-md-7">
          <h2 class="featurette-heading">OMG Oh yeah, it's that good. "Yess really"<br/><span class="text-muted">See for yourself.</span> <i class="fa fa-lg fa-thumbs-o-up"></i></h2>
          <p class="lead">Real-Time high quality, Easy to use, Extremely safe, No sign up!<br/>
		  Just give him or her your temporary secret key and room url.</br>
		  You can talk privately before you meet someone.<br/>
		  Check if there's chemistry or Romantic between the two of you!.<br/>
		  You can use it For fun, for your own protection and your business.<br/>
		  You can combine this with all social networks and dating sites</br>
		  And best off all it's 100% FREE.</p>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7">
          <h2 class="featurette-heading">And lastly, Your biggest dream in life (live).<br/><span class="text-muted">You Gona Love This. </span><i class="fa fa-lg fa-female"></i><i class="fa fa-heart-o"></i><i class="fa fa-lg fa-male"></i></h2>
          <p class="lead">We really hope that someday...<br/>
		  A lot of people can tell Amazing success stories about this.<br/>
		  And that they never forget the first day on <?=$sitename;?></br>
		  That they found the best relationship of their lives on <?=$sitename;?><br/>
		  (in love, in business OR both)<br/>
		  </p>
        </div>
        <div class="col-md-5">
          <img class="featurette-image img-responsive img-thumbnail" src="images/a2.jpg" alt="">
        </div>
      </div>

      <hr class="featurette-divider">

      <!-- /END THE FEATURETTES -->
<!--ADMINCMS-END-->

      <!-- FOOTER -->
      <footer>
	    <footer>Now <strong><? include ('count/online.php');?></strong> users online - <? include ('count/count.php');?> <br/><br/>
        <p class="pull-right"><a class="btn btn-success" href="#"><i class="fa fa-lg fa-arrow-up"></i> Back to top <i class="fa fa-lg fa-arrow-up"></i></a></p>
		<? include ('settings/footer.php');?>
        
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
	

<!-- Modal -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Here is how it works.</h4>
      </div>
      <div class="modal-body">
        1. Go to one of the 50 Cam rooms (we serve several private connections each room)<br/>
		2. When the topbar a pair, Give the browser access to your cam Click on accept.<br/>
		3. Now a secret Key is generated, Simply copy the text from the text box with your Key and the Room URL.<br/>
		4. Paste the text with the Key and Room URL in a email, DM or private mesage and send it to a person.<br/>
		<br/><small>(The text box look like this!)</small><br/>
		<div id="input1" class="alert alert-warning div">
			   Hi, i want to chat with You, Just Go to:<br/>
			   <BIG><strong><?=$siteurl;?>/private/room01.php</strong></BIG><br/>
			   Enter this Key to video chat with me.<br/>
			   <BIG><strong>HtuinQvdeZlpDr</strong></BIG><br/>
			   Please Hurry Up i'm already waiting.
			   </div>
			 

		Now you just wait till the person follows the Room URL and enters the Key!<br/><br/>
		Thats it, Enjoy ;)<br/><br/>
		<strong>Note!</strong> Do Not close or refresh the room page, this will generate a new secret key!</br>
		If you Do close or refresh the room page, The Key you just send to a person will simply NOT work anymore!<br>
		Than you need to start all over again.<br/>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->



<!-- Small modal -->
<!--button class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-sm">Small modal</button--->

<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
	<center>
	<h4>Don't keep this for yourself</h4>
	share the Joy and have fun with your friends!<br/><br/>
      <? include ('settings/share.php');?>
	  <small>Also s Great way to help us Grow </small><br/><BIG>Thanks For Your Support!</BIG><br/><br/>
	  </center>
    </div>
  </div>
</div>


  </body>
</html>
